Indra Bhurtel


***README***

Files included: closet.cpp, closet.h, closet_main.cpp, and makefile
--------------------------

1. The program contains four  files i.e. closet.cpp, closet.h, closet_main.cpp, and makefile 
2. closet.cpp contains the definations for all the functions being used.
3. closet.h has the function prototypes.
4. closet_main.cpp has our main.
5. makefile has the necessary command for the program compilation which help to speed up the compile process.

Compilation instructions:
-------------------------

Go to the destination folder where all the four files are located.
Then in the command window, type the following command. 
make ( make sure 'm' is not capitalized)
./closet ( make sure 'c' is not capitalized)
